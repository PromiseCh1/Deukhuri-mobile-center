<?php
/**
 * header.php
 * Admin panel header (top navbar).
 */
if (!defined('APP_START')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Direct access not allowed.');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> – Admin</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Google Font (optional) -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Admin CSS -->
    <link rel="stylesheet" href="assets/css/admin.css">
    <!-- Page-specific CSS (if any) -->
    <?php if (isset($page_css) && !empty($page_css)): ?>
        <link rel="stylesheet" href="assets/css/<?= htmlspecialchars($page_css) ?>">
    <?php endif; ?>
</head>
<body>
    <div class="admin-wrapper">
        <!-- Sidebar will be included separately -->
        <div class="admin-main">
            <!-- Top Navbar -->
            <header class="admin-header">
                <div class="header-left">
                    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle sidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="header-title">Dashboard</span> <!-- Dynamic title can be set -->
                </div>
                <div class="header-right">
                    <span class="user-name"><?= htmlspecialchars($_SESSION['full_name'] ?? 'User') ?></span>
                    <span class="role-badge <?= strtolower($_SESSION['role'] ?? 'staff') ?>">
                        <?= htmlspecialchars($_SESSION['role'] ?? 'Staff') ?>
                    </span>
                    <div class="dropdown">
                        <button class="dropdown-toggle" id="userDropdown">
                            <i class="fas fa-user-circle"></i>
                        </button>
                        <div class="dropdown-menu" id="dropdownMenu">
                            <a href="#"><i class="fas fa-user"></i> Profile</a>
                            <a href="<?= SITE_URL ?>/admin/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </div>
                </div>
            </header>
            <!-- Main content area -->
            <main class="admin-content"></main>