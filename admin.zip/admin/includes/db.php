<?php
declare(strict_types=1);

/**
 * db.php
 * Secure PDO database connection.
 * Returns $pdo object for all database operations.
 */

if (!defined('APP_START')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Direct access not allowed.');
}

if (!defined('DB_HOST')) {
    require_once __DIR__ . '/config.php';
}

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
        ]
    );
} catch (PDOException $e) {
    error_log('DB Connection Error: ' . $e->getMessage());
    if (APP_DEBUG) {
        die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
    } else {
        die('Database connection error. Please try again later.');
    }
}

// Optional global exception handler
// set_exception_handler(function($e) {
//     error_log('Uncaught Exception: ' . $e->getMessage());
//     if (!APP_DEBUG) {
//         http_response_code(500);
//         die('An internal error occurred.');
//     }
// });