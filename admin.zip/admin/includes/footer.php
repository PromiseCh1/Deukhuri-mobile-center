<?php
/**
 * footer.php
 * Admin panel footer.
 */
if (!defined('APP_START')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Direct access not allowed.');
}
?>
            </main> <!-- .admin-content -->
        </div> <!-- .admin-main -->
    </div> <!-- .admin-wrapper -->

    <!-- JavaScript -->
    <script src="assets/js/admin.js"></script>
    <!-- Page-specific JS if needed -->
    <?php if (isset($page_js) && !empty($page_js)): ?>
        <script src="assets/js/<?= htmlspecialchars($page_js) ?>"></script>
    <?php endif; ?>
</body>
</html>