<?php
declare(strict_types=1);

/**
 * functions.php
 * Reusable helper functions for the admin panel.
 */

if (!defined('APP_START')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Direct access not allowed.');
}

// ---------------------------------------------------------------------------
// Input/Output Helpers
// ---------------------------------------------------------------------------

/**
 * Escape output for HTML – prevents XSS.
 */
function escape(mixed $input): mixed
{
    if (is_array($input)) {
        return array_map('escape', $input);
    }
    return htmlspecialchars((string)$input, ENT_QUOTES, 'UTF-8');
}

/**
 * Alias for escape() – backward compatibility.
 */
function sanitize(mixed $input): mixed
{
    return escape($input);
}

/**
 * Sanitise input for storage – trims and strips tags.
 * Use for user input before validation (not for output).
 */
function sanitizeInput(mixed $input): mixed
{
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return trim(strip_tags((string)$input));
}

// ---------------------------------------------------------------------------
// HTTP Helpers
// ---------------------------------------------------------------------------

function isPost(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

function isGet(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'GET';
}

function isAjax(): bool
{
    return isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

function isHttps(): bool
{
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
           (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
}

function getClientIp(): ?string
{
    $ip = null;
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
    }
    return $ip;
}

// ---------------------------------------------------------------------------
// Redirection
// ---------------------------------------------------------------------------

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function redirectBack(string $fallback = ''): never
{
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    if ($referer) {
        redirect($referer);
    } elseif ($fallback) {
        redirect($fallback);
    } else {
        redirect(SITE_URL . '/admin/dashboard.php');
    }
}

// ---------------------------------------------------------------------------
// Authentication & Role Checks
// ---------------------------------------------------------------------------

function isLoggedIn(): bool
{
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

function isAdmin(): bool
{
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'Admin';
}

function isStaff(): bool
{
    return isLoggedIn() && isset($_SESSION['role']) &&
           ($_SESSION['role'] === 'Staff' || $_SESSION['role'] === 'Admin');
}

function hasRole(string $role): bool
{
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

function getCurrentUserId(): ?int
{
    return isLoggedIn() ? (int)$_SESSION['admin_id'] : null;
}

function getCurrentUserRole(): ?string
{
    return isLoggedIn() ? $_SESSION['role'] : null;
}

function getCurrentUserName(): ?string
{
    return isLoggedIn() ? $_SESSION['full_name'] : null;
}

// ---------------------------------------------------------------------------
// Flash Messages
// ---------------------------------------------------------------------------

function setFlashMessage(string $key, string $message): void
{
    if (!isset($_SESSION['__flash'])) {
        $_SESSION['__flash'] = [];
    }
    $_SESSION['__flash'][$key] = $message;
}

function displayFlashMessage(string $key, bool $keep = false): ?string
{
    if (isset($_SESSION['__flash'][$key])) {
        $msg = $_SESSION['__flash'][$key];
        if (!$keep) {
            unset($_SESSION['__flash'][$key]);
        }
        return $msg;
    }
    return null;
}

function hasFlashMessage(string $key): bool
{
    return isset($_SESSION['__flash'][$key]);
}

// ---------------------------------------------------------------------------
// CSRF Token (with optional expiration and single‑use)
// ---------------------------------------------------------------------------

function generateCsrfToken(): string
{
    if (empty($_SESSION[CSRF_TOKEN_NAME]) || !isset($_SESSION[CSRF_TOKEN_NAME . '_time'])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        $_SESSION[CSRF_TOKEN_NAME . '_time'] = time();
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

function getCsrfToken(): ?string
{
    return $_SESSION[CSRF_TOKEN_NAME] ?? null;
}

function verifyCsrfToken(string $token, bool $checkExpiry = false, int $lifetime = CSRF_TOKEN_LIFETIME): bool
{
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        return false;
    }

    if ($checkExpiry) {
        $time = $_SESSION[CSRF_TOKEN_NAME . '_time'] ?? 0;
        if (time() - $time > $lifetime) {
            return false;
        }
    }

    $valid = hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
    if ($valid) {
        // Clear token after successful verification (single‑use)
        clearCsrfToken();
    }
    return $valid;
}

function clearCsrfToken(): void
{
    unset($_SESSION[CSRF_TOKEN_NAME]);
    unset($_SESSION[CSRF_TOKEN_NAME . '_time']);
}

// ---------------------------------------------------------------------------
// Security Headers
// ---------------------------------------------------------------------------

function sendSecurityHeaders(): void
{
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer-when-downgrade');
    header("Permissions-Policy: geolocation=(), microphone=(), camera=()");
    if (isHttps() && APP_ENV === 'production') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}