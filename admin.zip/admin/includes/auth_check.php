<?php
declare(strict_types=1);

/**
 * auth_check.php
 * Authentication middleware for every admin page.
 */

if (!defined('APP_START')) {
    header('HTTP/1.1 403 Forbidden');
    exit('Direct access not allowed.');
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

// ---------------------------------------------------------------------------
// Session Configuration
// ---------------------------------------------------------------------------

session_name(SESSION_NAME);
session_set_cookie_params([
    'lifetime' => SESSION_TIMEOUT,
    'path'     => SESSION_COOKIE_PATH ?: '/',
    'domain'   => SESSION_COOKIE_DOMAIN ?: '',
    'secure'   => isHttps(),
    'httponly' => true,
    'samesite' => 'Lax'
]);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------------------------------------------------------------------------
// Optional: Session Hijacking Protection (IP + User-Agent)
// ---------------------------------------------------------------------------
/*
if (isset($_SESSION['client_ip']) && $_SESSION['client_ip'] !== getClientIp()) {
    $_SESSION = [];
    setFlashMessage('error', 'Session hijacking detected. Please log in again.');
    redirect(SITE_URL . '/admin/login.php');
}
if (isset($_SESSION['user_agent']) && $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
    $_SESSION = [];
    setFlashMessage('error', 'Session hijacking detected. Please log in again.');
    redirect(SITE_URL . '/admin/login.php');
}
$_SESSION['client_ip'] = getClientIp();
$_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
*/

// ---------------------------------------------------------------------------
// Session Timeout
// ---------------------------------------------------------------------------

if (isset($_SESSION['last_activity'])) {
    if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
        // Preserve flash messages before destroying
        $flash = $_SESSION['__flash'] ?? [];
        $_SESSION = [];
        $_SESSION['__flash'] = $flash;
        setFlashMessage('error', 'Your session has expired. Please log in again.');
        redirect(SITE_URL . '/admin/login.php');
    }
}
$_SESSION['last_activity'] = time();

// ---------------------------------------------------------------------------
// Session Regeneration (periodic)
// ---------------------------------------------------------------------------

if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} elseif (time() - $_SESSION['created'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}

// ---------------------------------------------------------------------------
// Authentication Check
// ---------------------------------------------------------------------------

if (!isLoggedIn()) {
    setFlashMessage('error', 'Please log in to access the admin panel.');
    redirect(SITE_URL . '/admin/login.php');
}

// ---------------------------------------------------------------------------
// Role-Based Access Control
// ---------------------------------------------------------------------------

/**
 * Require one or more roles for the current page.
 *
 * @param string|array $allowedRoles  Single role or array of allowed roles.
 * @param string       $redirectUrl   URL to redirect on failure.
 */
function requireRole(string|array $allowedRoles, string $redirectUrl = ''): void
{
    if (!isLoggedIn()) {
        setFlashMessage('error', 'Please log in.');
        redirect(SITE_URL . '/admin/login.php');
    }

    $userRole = $_SESSION['role'] ?? '';

    if (is_string($allowedRoles)) {
        $allowedRoles = [$allowedRoles];
    }

    // Admin has access to everything (overrides Staff restrictions)
    if ($userRole === 'Admin') {
        return;
    }

    if (!in_array($userRole, $allowedRoles, true)) {
        setFlashMessage('error', 'You do not have permission to access this page.');
        $redirectUrl = $redirectUrl ?: SITE_URL . '/admin/dashboard.php';
        redirect($redirectUrl);
    }
}

/**
 * Combined authentication and optional role check.
 * Call this after including the file.
 */
function authenticate(string|array|null $requiredRole = null, string $redirectUrl = ''): void
{
    // Already checked above, but re‑check for safety.
    if (!isLoggedIn()) {
        setFlashMessage('error', 'Please log in.');
        redirect(SITE_URL . '/admin/login.php');
    }

    if ($requiredRole !== null) {
        requireRole($requiredRole, $redirectUrl);
    }
}

// Optionally, if page defines REQUIRE_ROLE constant, apply it automatically.
if (defined('REQUIRE_ROLE')) {
    authenticate(REQUIRE_ROLE);
}